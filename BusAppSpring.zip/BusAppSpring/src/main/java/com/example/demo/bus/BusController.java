package com.example.demo.bus;

import com.example.demo.database.BusStopRepository;
import com.example.demo.database.BusStops;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;


import com.example.demo.database.PassenerRepository;
import com.example.demo.database.PassengerData;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/")
@SessionAttributes("dataMapClass")
public class BusController {
	private final PassenerRepository passengerRepo;
	private final BusStopRepository busStopRepository;

	public BusController(PassenerRepository passengerRepo, BusStopRepository busStopRepository){
		this.passengerRepo =passengerRepo;
		this.busStopRepository = busStopRepository;
	}

	@GetMapping("/")
	public ModelAndView home() {
		return new ModelAndView("/bus.jsp");
	}

	@PostMapping("/postdata")
	public ModelAndView post(DataMapClass dataMapClass, SessionStatus
			  sessionStatus) {
		PassengerData passengerData = new PassengerData();
		passengerData.setDate(dataMapClass.getDate());
		passengerData.setTime(dataMapClass.getTime());
		passengerData.setName(dataMapClass.getName()); 
		passengerData.setFromLocation(dataMapClass.getBoardingPoint()); 
		passengerData.setToLocation(dataMapClass.getDroppingPoint()); 
		passengerData.setContactNumber(dataMapClass.getContactNo()); 
		passengerData.setSeatNumber(dataMapClass.getSeatNo()); 
		
		passengerRepo.save(passengerData);
		sessionStatus.setComplete(); 
		return new ModelAndView("/payment.jsp","user", passengerData);
	}

	@PostMapping(value = "/post1stpage")
	public ModelAndView post2(DataMapClass dataMapClass) {
		String source = dataMapClass.getSource();
		List<BusStops> boardingPoints = busStopRepository.findAllByCity(source);
		String destination = dataMapClass.getDestination();
		List<BusStops> droppingPoints = busStopRepository.findAllByCity(destination);

		Set<Integer> bookedSeats = passengerRepo.findBookedSeats(dataMapClass.getDate(),dataMapClass.getTime());
		List<Integer> availableSeats = new ArrayList<>();
		for (int i = 1; i <= 20; i++) {
			if (!bookedSeats.contains(i)) {
				availableSeats.add(i);
			}
		}
		ModelAndView model = new ModelAndView("/index.jsp");
		model.addObject("boardingPoints", boardingPoints);
		model.addObject("droppingPoints", droppingPoints);
		model.addObject("seats", availableSeats);
		return model;
	}

	@GetMapping("/addCity")
	public ModelAndView cityAddPage() {
		return new ModelAndView("/cities.jsp");
	}

	@PostMapping("/addCity")
	public ModelAndView addCity(@RequestParam String city, @RequestParam String busStop) {

		busStopRepository.save(new BusStops(city, busStop));
		return new ModelAndView("/cities.jsp");
	}
}
